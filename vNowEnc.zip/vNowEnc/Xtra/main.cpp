
// NOTICE: 

//	This program is free software; you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation; either version 2 of the License, or
//	(at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


///////////////////////////////////////////////////////////////////////////
// HEADERS
///////////////////////////////////////////////////////////////////////////


//#define VDEXT_VIDEO_FILTER
//#define VDEXT_MAIN
//#define VDEXT_NOTMAIN



#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <vfw.h>

#include "resource.h"
#include "../include/Filter.h"





///////////////////////////////////////////////////////////////////////////
// FUNCTION DEFS
///////////////////////////////////////////////////////////////////////////

int vidNowDecRunProc(const FilterActivation *fa, const FilterFunctions *ff);
int vidNowDecStartProc(FilterActivation *fa, const FilterFunctions *ff);
int vidNowDecEndProc(FilterActivation *fa, const FilterFunctions *ff);
long vidNowDecParamProc(FilterActivation *fa, const FilterFunctions *ff);
int vidNowDecConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd);
static const char *openFileDlg(HWND hwnd, const char *oldfn);


LRESULT CALLBACK nPreviewWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

extern "C" int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat);
extern "C" void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff);


///////////////////////////////////////////////////////////////////////////
// DATA DEFS
///////////////////////////////////////////////////////////////////////////

//****************************************
// Structure where we hold our Global 
// filter specific Data, like dialog settings,
// and lookup tables.
//
// This is passed into every function ....
//****************************************
typedef struct MyFilterData {
 	char szAviPath[MAX_PATH];

	IFilterPreview *ifp;
    PAVIFILE pfile; 
    PAVISTREAM ppavi; 
	long streamSize;
	long trackStart;
	int mode;
	int contrast;

} MyFilterData;

MyFilterData *g_mfd;


void testAVIFile(char * filename, MyFilterData *mfd);



//****************************************
// Structure that tells vDub about our filter
// Holds name, description, and pointers to
// the functions vdub calls for the filter
// to do it's thing.
//****************************************
struct FilterDefinition filterDef_vidNowDec = {

    NULL, NULL, NULL,       // next, prev, module
    "VideoNowViewer - Beta",       // name
    "Video Now Test Viewer",
                            // desc
    "trevlac",               // maker
    NULL,                   // private_data
    sizeof(MyFilterData),   // inst_data_size

    NULL,                   // initProc
    NULL,                   // deinitProc
    vidNowDecRunProc,        // runProc
    vidNowDecParamProc,      // paramProc
    vidNowDecConfigProc,     // configProc
    NULL,     // stringProc
    vidNowDecStartProc,      // startProc
    vidNowDecEndProc,        // endProc

    NULL,          // script_obj
    NULL,        // fssProc

};

static FilterDefinition *fd_vidNowDec;


///////////////////////////////////////////////////////////////////////////
// FUNCTIONS
///////////////////////////////////////////////////////////////////////////


//****************************************
// VDub calls this exported function to 
// Add our filter to the list ..
//****************************************

int __declspec(dllexport) __cdecl VirtualdubFilterModuleInit2(FilterModule *fm, const FilterFunctions *ff, int& vdfd_ver, int& vdfd_compat) {
    if (!(fd_vidNowDec = ff->addFilter(fm, &filterDef_vidNowDec, sizeof(FilterDefinition))))
        return 1;

	//INITIALIZE_VTBLS;

	vdfd_ver = VIRTUALDUB_FILTERDEF_VERSION;
	vdfd_compat = VIRTUALDUB_FILTERDEF_COMPATIBLE;

    return 0;
}

//****************************************
// Exported function to remove us from the list
//****************************************
void __declspec(dllexport) __cdecl VirtualdubFilterModuleDeinit(FilterModule *fm, const FilterFunctions *ff) {
    ff->removeFilter(fd_vidNowDec);
}


//****************************************
// StartProc - Just before we start to filter
//
// Good place to .....
//****************************************
int vidNowDecStartProc(FilterActivation *fa, const FilterFunctions *ff) {
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;

	//if(mfd->ppavi)
	//	mfd->pgf = AVIStreamGetFrameOpen(mfd->ppavi,NULL);

	testAVIFile(mfd->szAviPath, mfd);



    return 0;
}


//****************************************
// RunProc gets called for each frame.
//
// This is where the filtering is done.
//****************************************

int vidNowDecRunProc(const FilterActivation *fa, const FilterFunctions *ff) {
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;
    PixDim w, h;
    Pixel32 *dst, *dst2;
	char theData[19201];
	long sampleStart;
	int byteCnt=0;
	int cont,holdByte, dbl;
	int lineCnt=0;
	unsigned int r,g,b, nextLine=120, addL;
	unsigned int level1 =  0x0F0F, level2 =  0x0F000F, level3 =  0x0F0F00;
	//level1=level2=level3=0;
	cont = mfd->contrast;


	//level1=level2=level3 = 0;

	if(mfd->ppavi ==0 ) return 0;


	sampleStart = (fa->pfsi->lCurrentFrame * 19600) + mfd->trackStart + 240 + 120 + 40;
	sampleStart = sampleStart / 4;


	if(AVIStreamRead(mfd->ppavi,sampleStart,4800 ,&theData, 19200, NULL, NULL) != 0)
		return 0;


	if(mfd->mode == 0) {

		h = fa->dst.h;
		do {
			dst = fa->dst.Address32(0,lineCnt++);
			w = fa->dst.w / 12;

			  do {
				  for(int Group=0;Group<3;Group++) {

					r = (theData[byteCnt ] & 0x0F)<<20; 
					g = (theData[byteCnt + nextLine ] & 0x0F)<<12; 
					b = (theData[byteCnt + nextLine ] & 0xF0)<<0; 
					*dst++ = r + g + b;

					g = (theData[byteCnt ] & 0xF0)<<8; 
					byteCnt++;
					r = (theData[byteCnt + nextLine ] & 0x0F)<<20; 
					b = (theData[byteCnt ] & 0x0F)<<4; 
					*dst++ = r + g + b;

					r = (theData[byteCnt ] & 0xF0)<<16; 
					g = (theData[byteCnt + nextLine ] & 0xF0)<<8; 
					byteCnt++;
					b = (theData[byteCnt + nextLine] & 0x0F)<<4; 
					*dst++ = r + g + b;

					r = (theData[byteCnt + nextLine ] & 0xF0)<<16; 
					b = (theData[byteCnt ] & 0xF0)<<0; 
					g = (theData[byteCnt ] & 0x0F)<<12; 
					*dst++ = r + g + b;

					byteCnt++;
				  }


				  byteCnt++; // The Audio

			  } while(--w);

			  byteCnt = byteCnt + 120;  // Next Line

		} while(--h);

	} else {
		
		h = 160;
		do {
			dst = fa->dst.Address32(0,lineCnt++);
			w = 12;

			if(h%2==0) {
			  *dst++ = 0x0;
			  do {

				  for(int Group=0;Group<3;Group++) {

					r = (theData[byteCnt] & 0x0F)<<4;		//Red
					g = (theData[byteCnt+ 120] & 0x0F)<<4;
					b = (theData[byteCnt+ 120] & 0xF0)<<0;

					addL = min(r+((g*6 + b)/20),255)-r;
					*dst++ = ((r+addL)<<16) + (addL<<8) + addL;
					*dst++= *(dst-1);

					r = (theData[byteCnt+121] & 0x0F)<<4;	//Green
					g = (theData[byteCnt] & 0xF0)<<0;
					b = (theData[byteCnt+1] & 0x0F)<<4;

					addL = min(g+((r*3 + b)/20),255)-g;
					*dst++ = ((g+addL)<<8) + (addL<<16) + addL;
					*dst++= *(dst-1);
					byteCnt++;

					addL = min(b+((r*3 + g*6)/20),255)-b;	//Blue
					*dst++ = ((b+addL)<<0) + (addL<<16) + (addL<<8);
					*dst++= *(dst-1);


					r = (theData[byteCnt] & 0xF0)<<0;		//Red
					g = (theData[byteCnt+ 120] & 0xF0)<<0;
					b = (theData[byteCnt+ 121] & 0x0F)<<4;

					addL = min(r+((g*6 + b)/20),255)-r;
					*dst++ = ((r+addL)<<16) + (addL<<8) + addL;
					*dst++= *(dst-1);

					byteCnt++;

					r = (theData[byteCnt+120] & 0xF0)<<0;	//Green
					g = (theData[byteCnt] & 0x0F)<<4;
					b = (theData[byteCnt] & 0xF0)<<0;

					addL = min(g+((r*3 + b)/20),255)-g;
					*dst++ = ((g+addL)<<8) + (addL<<16) + addL;
					*dst++= *(dst-1);

					addL = min(b+((r*3 + g*6)/20),255)-b;	//Blue
					*dst++ = ((b+addL)<<0) + (addL<<16) + (addL<<8);
					*dst++= *(dst-1);

					byteCnt++;
				  }

/***********	  for(int Group=0;Group<3;Group++) {

					holdByte = min( ((theData[byteCnt] & 0x0F)<<4) + cont   ,255);
					*dst++ = (holdByte<<16) + level1; // & 0xFF0000; Red
					*dst++= *(dst-1);

					holdByte = min( ((theData[byteCnt] & 0xF0)<<0) + cont   ,255);
				    *dst++ = (holdByte<<8) + level2; // & 0x00FF00; Green
					*dst++= *(dst-1);
					byteCnt++;

					holdByte = min( ((theData[byteCnt] & 0x0F)<<4) + cont   ,255);
				    *dst++ = (holdByte<<0) + level3; // & 0xFF0000; Blue
					*dst++= *(dst-1);

					holdByte = min( ((theData[byteCnt] & 0xF0)<<0) + cont   ,255);
					*dst++ = (holdByte<<16) + level1; // & 0xFF0000; Red
					*dst++= *(dst-1);

					byteCnt++;

					holdByte = min( ((theData[byteCnt] & 0x0F)<<4) + cont   ,255);
				    *dst++ = (holdByte<<8) + level2; // & 0x00FF00; Green
					*dst++= *(dst-1);

					holdByte = min( ((theData[byteCnt] & 0xF0)<<0) + cont   ,255);
				    *dst++ = (holdByte<<0) + level3; // & 0xFF0000; Blue
					*dst++= *(dst-1);

					byteCnt++;
				  }
				  */

					byteCnt++; // The Audio

				} while(--w);

				dst2 = fa->dst.Address32(0,lineCnt-1);
				dst = fa->dst.Address32(0,lineCnt++);
				for(dbl=0;dbl<433;dbl++) {
					*dst++=*dst2++;
				}

			} else {

			  do {
				  for(int Group=0;Group<3;Group++) {

					r = (theData[byteCnt-120] & 0x0F)<<4;		//Green
					g = (theData[byteCnt] & 0x0F)<<4;
					b = (theData[byteCnt] & 0xF0)<<0;

					addL = min(g+((r*3 + b)/20),255)-g;
					*dst++ = ((g+addL)<<8) + (addL<<16) + addL;
					*dst++= *(dst-1);

					addL = min(b+((r*3 + g*6)/20),255)-b;		//Blue
					*dst++ = ((b+addL)<<0) + (addL<<16) + (addL<<8);
					*dst++= *(dst-1);

					byteCnt++;

					r = (theData[byteCnt] & 0x0F)<<4;		//Red
					g = (theData[byteCnt-121] & 0xF0)<<0;
					b = (theData[byteCnt-120] & 0x0F)<<4;

					addL = min(r+((g*6 + b)/20),255)-r;
					*dst++ = ((r+addL)<<16) + (addL<<8) + addL;
					*dst++= *(dst-1);


					r = (theData[byteCnt-120] & 0xF0)<<0;		//Green
					g = (theData[byteCnt] & 0xF0)<<0;
					b = (theData[byteCnt+1] & 0x0F)<<4;

					addL = min(g+((r*3 + b)/20),255)-g;
					*dst++ = ((g+addL)<<8) + (addL<<16) + addL;
					*dst++= *(dst-1);

					byteCnt++;

					addL = min(b+((r*3 + g*6)/20),255)-b;		//Blue
					*dst++ = ((b+addL)<<0) + (addL<<16) + (addL<<8);
					*dst++= *(dst-1);


					r = (theData[byteCnt] & 0xF0)<<0;		//Red
					g = (theData[byteCnt-120] & 0x0F)<<4;
					b = (theData[byteCnt-120] & 0xF0)<<0;

					addL = min(r+((g*6 + b)/20),255)-r;
					*dst++ = ((r+addL)<<16) + (addL<<8) + addL;
					*dst++= *(dst-1);

					byteCnt++;
				  }

/**********		  for(int Group=0;Group<3;Group++) {

  					holdByte = min( ((theData[byteCnt] & 0x0F)<<4) + cont   ,255);
				    *dst++ = (holdByte<<8) + level2; // & 0x00FF00; Green
					*dst++= *(dst-1);

					holdByte = min( ((theData[byteCnt] & 0xF0)<<0) + cont   ,255);
				    *dst++ = (holdByte<<0) + level3; // & 0xFF0000; Blue
					*dst++= *(dst-1);

					byteCnt++;

					holdByte = min( ((theData[byteCnt] & 0x0F)<<4) + cont   ,255);
					*dst++ = (holdByte<<16) + level1; // & 0xFF0000; Red
					*dst++= *(dst-1);

  					holdByte = min( ((theData[byteCnt] & 0xF0)<<0) + cont   ,255);
				    *dst++ = (holdByte<<8) + level2; // & 0x00FF00; Green
					*dst++= *(dst-1);

					byteCnt++;

					holdByte = min( ((theData[byteCnt] & 0x0F)<<4) + cont   ,255);
				    *dst++ = (holdByte<<0) + level3; // & 0xFF0000; Blue
					*dst++= *(dst-1);

					holdByte = min( ((theData[byteCnt] & 0xF0)<<0) + cont   ,255);
					*dst++ = (holdByte<<16) + level1; // & 0xFF0000; Red
					*dst++= *(dst-1);

					byteCnt++;
				  }
****************/

					byteCnt++; // The Audio
				} while(--w);

				dst2 = fa->dst.Address32(0,lineCnt-1);
			    dst = fa->dst.Address32(0,lineCnt++);
				for(dbl=0;dbl<433;dbl++) {
					*dst++=*dst2++;
				}

				*dst++ = 0x0;
			}
			//dst = (Pixel32 *)((char *)dst + fa->dst.modulo);
			//dst = (Pixel *)((char *)dst - fa->dst.pitch);

		} while(--h);

	}



    return 0;
}


//****************************************
// EndProc - Done Filtering 
//
// Good place to clean up 
//****************************************
int vidNowDecEndProc(FilterActivation *fa, const FilterFunctions *ff) {
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;

//	if(mfd->pgf) AVIStreamGetFrameClose(mfd->pgf);	// close the stream
    if(mfd->pfile) AVIFileRelease(mfd->pfile);  // closes the file 
	mfd->ppavi = 0;

    return 0;
}


//****************************************
// ParamProc - Set the Frame size
//
// Good place to .....
//****************************************
long vidNowDecParamProc(FilterActivation *fa, const FilterFunctions *ff) {
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;


	if(mfd->mode == 0) {
		fa->dst.w = 144;
		fa->dst.h = 80;
	} else {
		fa->dst.w = 433;
		fa->dst.h = 320;
	}

	fa->dst.pitch = (fa->dst.w*4 + 7) & -8;

	//mfd->pfile = 0;
	//mfd->ppavi = 0;


    return FILTERPARAM_SWAP_BUFFERS;
}


//****************************************
// ConfigDlgProc - Controls our configuration dialog
//
// This is where you need to do windows programing.
//****************************************
BOOL CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam) {
    MyFilterData *mfd = (MyFilterData *)GetWindowLong(hdlg, DWL_USER);

	char buf[50];
	HWND hWnd;


	//

    switch(msg) {
        case WM_INITDIALOG:
            SetWindowLong(hdlg, DWL_USER, lParam);
            mfd = (MyFilterData *)lParam;


			SetDlgItemText(hdlg, IDC_FILE, mfd->szAviPath);
            CheckDlgButton(hdlg, IDC_MODE0, mfd->mode==0?BST_CHECKED:BST_UNCHECKED);
            CheckDlgButton(hdlg, IDC_MODE1, mfd->mode==1?BST_CHECKED:BST_UNCHECKED);



			
			if (mfd->ifp) {
				mfd->ifp->InitButton(GetDlgItem(hdlg, IDC_PREVIEW));
			}

			hWnd = GetDlgItem(hdlg, IDC_CONTRAST);
			SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(0, 255));
			SendMessage(hWnd, TBM_SETTICFREQ, 5 , 0);
			SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, mfd->contrast);
		

			if (mfd->ifp)
				mfd->ifp->InitButton(GetDlgItem(hdlg, IDC_PREVIEW));


            return TRUE;

		case WM_HSCROLL:
			mfd->contrast = SendMessage(GetDlgItem(hdlg, IDC_CONTRAST), TBM_GETPOS, 0, 0);
			mfd->ifp->RedoFrame();
            return TRUE;



            return TRUE;

        case WM_COMMAND:
            switch(LOWORD(wParam)) {
            case IDOK:
                if(IsDlgButtonChecked(hdlg, IDC_MODE0)) mfd->mode=0;
                if(IsDlgButtonChecked(hdlg, IDC_MODE1)) mfd->mode=1;

                EndDialog(hdlg, 0);
                return TRUE;
            case IDCANCEL:
                EndDialog(hdlg, 1);
                return FALSE;
			case IDC_PREVIEW:
				if (mfd->ifp && mfd->ppavi)
					mfd->ifp->Toggle(hdlg);
				return TRUE;

			case IDC_MODE0:
			case IDC_MODE1:
                if(IsDlgButtonChecked(hdlg, IDC_MODE0)) mfd->mode=0;
                if(IsDlgButtonChecked(hdlg, IDC_MODE1)) mfd->mode=1;
				//mfd->ifp->UndoSystem();
				mfd->ifp->RedoSystem();
				return TRUE;


			case IDC_FILE_BROWSE:
				if (const char *fn = openFileDlg(hdlg, mfd->szAviPath)) {
					SetDlgItemText(hdlg, IDC_FILE, fn);
					strcpy(mfd->szAviPath, fn);
					testAVIFile(mfd->szAviPath, mfd);
					sprintf(buf,"Frames %d (%.3f Sec)", (mfd->streamSize - mfd->trackStart)/19600
						,((mfd->streamSize - mfd->trackStart)/19600)/18.0    );
					SetDlgItemText(hdlg, IDC_FRAMES, buf);
					//mfd->ifp->UndoSystem();
					mfd->ifp->RedoSystem();
				}
				return TRUE;


            }
            break;
    }

    return FALSE;
}




//****************************************
// ConfigProc - Just before our dialog box is opened
//
// This is where you .....
//****************************************
int vidNowDecConfigProc(FilterActivation *fa, const FilterFunctions *ff, HWND hwnd) {
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;

	int x;
	//---- Setup preview w/ callback on toggle
	mfd->ifp = fa->ifp;

    x =  DialogBoxParam(fa->filter->module->hInstModule,
            MAKEINTRESOURCE(IDD_FILTER_VIDNOWDEC), hwnd,
            (DLGPROC) ConfigDlgProc, (LPARAM)fa->filter_data);
	return x;

}




static const char *openFileDlg(HWND hwnd, const char *oldfn) {
	OPENFILENAME ofn;
	static char szFile[MAX_PATH];
	char szFileTitle[MAX_PATH];

	///////////////

	if (oldfn)
		strcpy(szFile, oldfn);

	szFileTitle[0]=0;

	ofn.lStructSize			= sizeof (OPENFILENAME) ;
	ofn.hwndOwner			= hwnd;
	ofn.lpstrFilter			= "WAV file (*.wav,*.avs)\0*.wav;*.avs\0All files (*.*)\0*.*\0";
	ofn.lpstrCustomFilter	= NULL;
	ofn.nFilterIndex		= 1;
	ofn.lpstrFile			= szFile;
	ofn.nMaxFile			= sizeof szFile;
	ofn.lpstrFileTitle		= szFileTitle;
	ofn.nMaxFileTitle		= sizeof szFileTitle;
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrTitle			= "Select WAV";
	ofn.Flags				= OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY ;//| OFN_ENABLESIZING;
	ofn.lpstrDefExt			= NULL;

	if (GetOpenFileName(&ofn))
		return szFile;

	return NULL;
}

void testAVIFile(char * filename, MyFilterData *mfd) {


  LONG hr; //--- Return code from file open.  0 is good 
  AVIFILEINFO pfi; //--- Structure to hold File Info 
  //AVISTREAMINFO psi; //--- Structure to hold Stream Info (where the fccHandler is) 
  //HRESULT hresult; 
  long wavSize;
  WAVEFORMAT waveFormat;
  char junk[48];

  int cnt;

  //char buf[20];
  
     

//---- Open the file.  If you don't get a zero back, Tell avs there  was an error 
  hr = AVIFileOpen(&mfd->pfile, filename, OF_READ, NULL); 
  if (hr != 0){ 
      return; 
  } 
  

//---- Get the File Info into our local structure so we can look 
   AVIFileInfo(mfd->pfile, &pfi, sizeof(pfi)); 


    //    if (AVIFileGetStream(pfile, &ppavi, NULL, streamtypeVIDEO) != AVIERR_OK) 
   AVIFileGetStream(mfd->pfile, &mfd->ppavi, streamtypeAUDIO, 0);
    //    break; 
  
	if(AVIStreamReadFormat(mfd->ppavi,AVIStreamStart(mfd->ppavi),NULL, &wavSize))
		 return;

	if(AVIStreamReadFormat(mfd->ppavi,AVIStreamStart(mfd->ppavi),&waveFormat, &wavSize))
		 return;
	
	LONG lSize;
	//if(
		cnt = AVIStreamRead(mfd->ppavi,0,AVISTREAMREAD_CONVENIENT, NULL, 0, &lSize, NULL); //)
	//	return;

	mfd->streamSize = AVIStreamLength(mfd->ppavi) * 4;

	mfd->trackStart = 0;
	int samples = 0;


	bool doLoop = true;
	do {

	  AVIStreamRead(mfd->ppavi,samples,10 ,&junk, 40, &lSize, NULL);
	  samples = samples + 10;

	  if(lSize != 40) return; //Error we did not get a good read

	  for(int i=0;i<40;i=i++) {

		  //Look for hex 81 E3 E3 C7 C7 81 81 E3 C7
		  if((junk[i] + junk[i+1] + junk[i+2] + junk[i+3] + junk[i+4]
			  + junk[i+5] + junk[i+6] + junk[i+7] + junk[i+8] ) == -639 )  {
			  doLoop = false;
			  break;
		  }
		mfd->trackStart++;
	  }

	}  while (doLoop);



} 
