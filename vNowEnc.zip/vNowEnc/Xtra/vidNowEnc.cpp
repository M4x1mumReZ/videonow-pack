
//#include "stdafx.h"
#include <windows.h>
#include <vfw.h>
#include <stdio.h>
#include <time.h>

#include <iostream> 

using namespace std;



//******** Those Global Variables **********

PAVISTREAM paviA; 
PAVISTREAM paviV; 
PGETFRAME pgf;

//**** We pass a fame around in these ****
BYTE frame[108*160];
BYTE audio[1960];


//**** Frame Headers ********
const BYTE h1[] = {0x81, 0xe3, 0xe3, 0xc7, 0xc7, 0x81, 0x81, 0xe3, 0xc7};

BYTE h2[] = {
		0x00,0x00,0x02,0x01,0x04,0x02,0x06,0x03,0xFF,
		0x08,0x04,0x0A,0x05,0x0C,0x06,0x0E,0x07,0xFF,
		0x11,0x08,0x13,0x09,0x15,0x0A,0x17,0x0B,0xFF,
		0x19,0x0C,0x1B,0x0D,0x1D,0x0E,0x1F,0x0F,0xFF,
		0x00,0x28,0x02,0x29,0x04,0x2A,0x06,0x2B,0xFF,
		0x08,0x2C,0x0A,0x2D,0x0C,0x2E,0x0E,0x2F,0xFF,
		0x11,0x30,0x13,0x31,0x15,0x32,0x17,0x33,0xFF,
		0x19,0x34,0x1B,0x35,0x1D,0x36,0x1F,0x37,0xFF,
		0x00,0x38,0x02,0x39,0x04,0x3A,0x06,0x3B,0xFF,
		0x08,0x3C,0x0A,0x3D,0x0C,0x3E,0x0E,0x3F,0xFF,
		0x11,0x40,0x13,0x41,0x15,0x42,0x17,0x43,0xFF,
		0x19,0x44,0x1B,0x45,0x1D,0x46,0x1F,0x47,0xFF};

const BYTE h3[] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};







//----------------------------------------------
// OpenAVIFile - Open the input and check it out
//
//----------------------------------------------
bool OpenAVIFile(char * filename , PAVIFILE * pFile) {

  

//**** Remove Quotes from file name *******	
  char * p;  
  if ('"'  == *filename)  filename++;      /* remove leading double quote (") */
  p = filename + strlen(filename) - 1;
  if ('"'  == *p)  *p=0;           /* remove trailing double quote */


//---- Open the file.  
  if(AVIFileOpen(pFile, filename, OF_READ, NULL) != 0) return false; 
  




  //***** File Info *******

//---- Get the File Info into our local structure so we can look 
  AVIFILEINFO pfi; 
  AVIFileInfo(*pFile, &pfi, sizeof(pfi)); 

  cout<<"InputFile: "<< filename << "\n\n";




  //***** Audio Info *******

  PCMWAVEFORMAT pwih;
  long headerSize = 16;
//---- Get the Audio Stream into ppavi -----
   AVIFileGetStream(*pFile, &paviA, streamtypeAUDIO, 0);
   if (paviA == NULL)  return false; 

//---- Get the size of the Audio Stream header into headerSize
	if(AVIStreamReadFormat(paviA,AVIStreamStart(paviA),&pwih, &headerSize))
		return false;


 cout<<"Audio:\t BitsPerSample\t"<< pwih.wBitsPerSample << "\n";
 cout<<"      \t Channels\t"<< pwih.wf.nChannels << "\n";
 cout<<"      \t SampleRate\t"<< pwih.wf.nSamplesPerSec << "\n\n";


  //***** Video Info *******

  long bmiSize = 40;
  BITMAPINFOHEADER bmih;
  AVISTREAMINFO psi; 

   AVIFileGetStream(*pFile, &paviV, streamtypeVIDEO, 0);
   if (paviV == NULL)  return false; 
  
   AVIStreamInfo(paviV, &psi, sizeof(psi)); 

   if(AVIStreamReadFormat(paviV,AVIStreamStart(paviV),&bmih, &bmiSize))
	 return false;

    cout<<"Video:\t Rate\t"<< pfi.dwRate << "\n";
    cout<<"      \t Width\t"<< bmih.biWidth << "\n";
	cout<<"      \t Height\t"<< bmih.biHeight << "\n";
	cout<<"      \t bitsPerPixel\t"<< bmih.biBitCount << "\n\n";


	pgf = AVIStreamGetFrameOpen(paviV,NULL);


   //iNumFrames=AVIStreamLength(pStream);
   

	return true;
} 

//----------------------------------------------
// GetVideo - Get a Frame and convert to VDN format.
//	
//----------------------------------------------

inline bool GetVideo2(int frameNum, BYTE * buf) { 

	//LPBITMAPINFOHEADER lpbih;
	//lpbih = (LPBITMAPINFOHEADER) AVIStreamGetFrame(pgf, frame);

	BYTE r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11;
	BYTE g0,g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11;
	BYTE b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11;
	int h=0,w=0;

	BYTE* pDIB = (BYTE*) AVIStreamGetFrame(pgf, frameNum);
	if(pDIB==NULL) return false;

	pDIB = pDIB + sizeof(BITMAPINFOHEADER);

	pDIB = pDIB + 144*79*3; // Move to top left
	
	//ZeroMemory(buf,120*160);

	// 2 Lines of output at a time
	h = 80;
	do {

		w = 12;
		do {  //*** We do 12 pixels input 12*12 = 144
			  //*** which is 18 bytes out 18*12 = 216/2 = 108

			b0 = (*pDIB++) & 0xF0;
			g0 = ((*pDIB++) & 0xF0)>>4;
			r0 = ((*pDIB++) & 0xF0)>>4;

			b1 = ((*pDIB++) & 0xF0)>>4;
			g1 = (*pDIB++) & 0xF0;
			r1 = ((*pDIB++) & 0xF0)>>4;

			b2 = ((*pDIB++) & 0xF0)>>4;
			g2 = (*pDIB++) & 0xF0;
			r2 = (*pDIB++) & 0xF0;

			b3 = (*pDIB++) & 0xF0;
			g3 = ((*pDIB++) & 0xF0)>>4;
			r3 = (*pDIB++) & 0xF0;

			b4 = (*pDIB++) & 0xF0;
			g4 = ((*pDIB++) & 0xF0)>>4;
			r4 = ((*pDIB++) & 0xF0)>>4;

			b5 = ((*pDIB++) & 0xF0)>>4;
			g5 = (*pDIB++) & 0xF0;
			r5 = ((*pDIB++) & 0xF0)>>4;

			b6 = ((*pDIB++) & 0xF0)>>4;
			g6 = (*pDIB++) & 0xF0;
			r6 = (*pDIB++) & 0xF0;

			b7 = (*pDIB++) & 0xF0;
			g7 = ((*pDIB++) & 0xF0)>>4;
			r7 = (*pDIB++) & 0xF0;

			b8 = (*pDIB++) & 0xF0;
			g8 = ((*pDIB++) & 0xF0)>>4;
			r8 = ((*pDIB++) & 0xF0)>>4;

			b9 = ((*pDIB++) & 0xF0)>>4;
			g9 = (*pDIB++) & 0xF0;
			r9 = ((*pDIB++) & 0xF0)>>4;

			b10 = ((*pDIB++) & 0xF0)>>4;
			g10 = (*pDIB++) & 0xF0;
			r10 = (*pDIB++) & 0xF0;

			b11 = (*pDIB++) & 0xF0;
			g11 = ((*pDIB++) & 0xF0)>>4;
			r11 = (*pDIB++) & 0xF0;

				
			*buf++ = r0|g1;
			*buf++ = b1|r2;
			*buf++ = g3|b3;
			*buf++ = r4|g5;
			*buf++ = b5|r6;
			*buf++ = g7|b7;
			*buf++ = r8|g9;
			*buf++ = b9|r10;
			*buf++ = g11|b11;
			buf = buf + 99;  //Begining of next line

	
			*buf++ = g0|b0;
			*buf++ = r1|g2;
			*buf++ = b2|r3;
			*buf++ = g4|b4;
			*buf++ = r5|g6;
			*buf++ = b6|r7;
			*buf++ = g8|b8;
			*buf++ = r9|g10;
			*buf++ = b10|r11;
			buf = buf - 108;  //Back to next byte on prior line

		} while(--w);
		buf=buf + 108;
		pDIB = pDIB - 864;  // Move back 2 lines * 144 Pixels * 3bytes
							// We work bottom up because a 
							// DIB is upside down.

	} while(--h);



	return true;

}

//----------------------------------------------
// GetVideo - Get a Frame and convert to VDN format.
//	
//----------------------------------------------

inline bool GetVideo(int frameNum, BYTE * buf) { 

	//LPBITMAPINFOHEADER lpbih;
	//lpbih = (LPBITMAPINFOHEADER) AVIStreamGetFrame(pgf, frame);

	BYTE r0,r1;
	BYTE g0,g1;
	BYTE b0,b1;
	int h=0,w=0;

	BYTE* pDIB = (BYTE*) AVIStreamGetFrame(pgf, frameNum);
	if(pDIB==NULL) return false;

	pDIB = pDIB + sizeof(BITMAPINFOHEADER);

	pDIB = pDIB + 432*159*3; // Move to top left
	
	//ZeroMemory(buf,120*160);

	// Line 1 of output at a time
	h = 160;
	do {

		if(h%2==0) {		//== DIB is GBR GBR Top to bottom in memory
			pDIB = pDIB+3;	//== Skip 1st Pixel On RGB lines

			w = 36;
			do {  			 
				
				pDIB = pDIB + 2; // Go to _ _R

				r0 = ((*pDIB) & 0xF0)>>4;

				pDIB = pDIB+5;
				g0 = ((*pDIB) & 0xF0);

				pDIB = pDIB+5;
				b0 = ((*pDIB) & 0xF0)>>4;

				pDIB = pDIB+8;
				r1 = ((*pDIB) & 0xF0)>>0;

				pDIB = pDIB+5;
				g1 = ((*pDIB) & 0xF0)>>4;

				pDIB = pDIB+5;
				b1 = (*pDIB) & 0xF0;

				pDIB = pDIB + 6;

					
				*buf++ = r0|g0;
				*buf++ = b0|r1;
				*buf++ = g1|b1;

			} while(--w);

			pDIB = pDIB - 3;

		}else {

			w = 36;
			do {  			  

				pDIB = pDIB+1;
				g0 = ((*pDIB) & 0xF0)>>4;

				pDIB = pDIB+5;
				b0 = ((*pDIB) & 0xF0)>>0;

				pDIB = pDIB+8;
				r0 = ((*pDIB) & 0xF0)>>4;

				pDIB = pDIB+5;
				g1 = ((*pDIB) & 0xF0)>>0;

				pDIB = pDIB+5;
				b1 = ((*pDIB) & 0xF0)>>4;

				pDIB = pDIB+8;
				r1 = (*pDIB) & 0xF0;

				pDIB = pDIB+4;

					
				*buf++ = g0|b0;
				*buf++ = r0|g1;
				*buf++ = b1|r1;

			} while(--w);
		}

		pDIB = pDIB - (2*432*3);  // Move back 2 lines * 432 Pixels * 3bytes
	} while(--h);



	return true;

}


//----------------------------------------------
// GetAudio - Send back a video frames worth of audio
//	
//----------------------------------------------

inline bool GetAudio(int frameNum, BYTE * buf) { 

	if(AVIStreamRead(paviA, frameNum*980, 980, buf, 1960,NULL, NULL)!=0) 
		return false;

	return true;

}



//----------------------------------------------
// writeFrames - Write a VDN frame to a file
//
// frameNum = Input frame
// fp = pointer to open file to write to	
//----------------------------------------------

bool writeFrames(int frameNum,FILE *fp) {


	//***** pointers to globals
	BYTE * h2p = h2;
	BYTE * aud = audio;
	BYTE * vid = frame;


	//*** Make sure we get Aud/Vid back
	if(GetVideo(frameNum, frame)) {
		if(GetAudio(frameNum, audio)) {


			//*** Frame Header 1 with Audio
			for(int i=0;i<24;i++) { 
				fwrite(h1,9,1,fp);
				fwrite(aud++,1,1,fp);
			}

			//*** Frame Header 2 with Audio
			for(i=0;i<12;i++) { 
				fwrite(h2p,9,1,fp);
				h2p=h2p+9;
				fwrite(aud++,1,1,fp);
			}

			//*** Frame  Header 3 with Audio
			for(i=0;i<4;i++) { 
				fwrite(h3,9,1,fp);
				fwrite(aud++,1,1,fp);
			}


			//*** Frame Data with Audio
			for(i=0;i<(160*12);i++ ) {
				fwrite(vid,9,1,fp);
				vid=vid+9;
				fwrite(aud++,1,1,fp);
			}
			return true;
		}

	}
	
	return false;

}



//----------------------------------------------
// writeHeader - Write RIFF and VDN file header
//
// fp = pointer to open file to write to	
//----------------------------------------------

bool writeHeader(FILE *fp) {

	BYTE dummyHeader[560];

	//===== Setup RIFF header ====
	WAVEFORMATEX wf;

	wf.wFormatTag=1;
	wf.nChannels=2;
	wf.wBitsPerSample=16;
	wf.nBlockAlign=wf.nChannels*wf.wBitsPerSample/8;
	wf.nSamplesPerSec=44100;
	wf.nAvgBytesPerSec=wf.nSamplesPerSec*wf.nBlockAlign;



	//===== Need to fill in the sizes later 
	fwrite("RIFF\0\0\0\0WAVEfmt \20\0\0\0",20,1,fp);
	fwrite(&wf,16,1,fp);
	fwrite("data\0\0\0\0",8,1,fp);

	//===== dummy header for VDN format
	ZeroMemory(dummyHeader,560);
	fwrite(dummyHeader,560,1,fp);


	return true;

}



//----------------------------------------------
// finalizeFile - Fill in RIFF header sizes and close
//
// fp = pointer to open file to write to	
//----------------------------------------------

void finalizeFile(FILE *fp) {

	DWORD p;


	/* complete WAV header */
	fflush(fp);
	p=ftell(fp);
	fseek(fp,4,SEEK_SET);
	_putw(p-8,fp);
	fflush(fp);
	fseek(fp,40,SEEK_SET);
	_putw(p-44,fp);
	fflush(fp);
	fclose(fp);

}


//----------------------------------------------
// main - Starting Point
//
//----------------------------------------------

int main(int argc, char* argv[])
{

    PAVIFILE pFile; 
	FILE *fp;
	char outFile[256];
	int fileCnt=1;
	int framesPerFile=0;
	long startTime, endTime;

	
	time(&startTime);


	//==== Need at least the in file name
	if(argc<2) {
		cout<<"usage: vidNowEnc.exe <inFilename> <framesPerFile>\n";
		return 0;
	}


	//==== 3rd arg is framesPer out File
	if(argc>2) framesPerFile = atoi(argv[2]);



	//===== Initialize =====
	AVIFileInit();

	//===== Setup Avi Streams =====
	if(OpenAVIFile(argv[1], &pFile)) {

		int iNumFrames=AVIStreamLength(paviV);	// Frames in
		int iProcessedFrameCnt = 0;				// Processed Frames

		//=== All frames in 1 file
		if(framesPerFile == 0) framesPerFile = iNumFrames;
		int iFramesThisFile;


		//==== Loop thru all input frames =====
		do {

			//==== Open an output File ====
			sprintf(outFile, "VDN Track %02d.wav",fileCnt++);
			if (!(fp=fopen(outFile,"wb"))) {
				cout<<"\nCould Not open output file: --"<< outFile <<"--\n\n";
				return 1;
			}

			//===== Write VNW & RIFF file Header
			writeHeader(fp);


			//===== Process 1 output file until we run out of frames
			//===== or we need a file break for a new output file
			iFramesThisFile = framesPerFile;
			do {
			//===== Write VNW frames
				cout<<"writing frame: "<< iProcessedFrameCnt + 1 << " Of " << iNumFrames << " Frames\r";
				writeFrames(iProcessedFrameCnt++,fp);
			} while (--iFramesThisFile && (iNumFrames > iProcessedFrameCnt) );


			//===== Finalize VNW file with RIFF sizes
			finalizeFile(fp);

		} while(iNumFrames > iProcessedFrameCnt);



		//===== Clean Up
		if(pgf) AVIStreamGetFrameClose(pgf);	// close the stream
		AVIStreamRelease(paviA);
		AVIStreamRelease(paviV);
		if(pFile) AVIFileRelease(pFile);  // closes the file 

		time(&endTime);
		cout<<"\nDone in "<< endTime - startTime << " seconds\n";


	}

	AVIFileExit();


	return 0;
}