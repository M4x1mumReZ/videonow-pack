#include <stdio.h>

main(int argc, char *argv[])
{ if(argc == 1)
  { printf("Not enough arguments.\nUsage: wavinfo [file]");
    exit(3);
  }
  FILE * fin;
  FILE * fout;
  char * buffer;
  fin = fopen(argv[1], "rb");
  if(!fin) exit(1);
  fseek(fin, 20, 1);
  unsigned short format;
  fread(&format, 2, 1, fin);
  printf("format: %i", format);
  if(format != 1)
  { printf("\nPCM Format code invalid.\nEither file is corrupted or data is not PCM.");
    fclose(fin);
    exit(1);
  }
  unsigned short channels;
  fread(&channels, 2, 1, fin);
  printf("\nchannels: %i", channels);
  long samprate;
  fread(&samprate, 4, 1, fin);
  printf("\nsample rate: %li", samprate);
  long byterate;
  fread(&byterate, 4, 1, fin);
  unsigned short blockalign;
  fread(&blockalign, 2, 1, fin);
  unsigned short bitsamp;
  fread(&bitsamp, 2, 1, fin);
  unsigned short rblockalign = (channels*bitsamp)/8;
  unsigned long rbyterate = 176400;
  printf("\nbit/sample: %i", bitsamp);
  printf("\nReported byterate: %li", byterate);
  printf("\nReal byterate: %li", rbyterate);
  printf("\nReported blockalign: %i", blockalign);
  printf("\nReal blockalign: %i", rblockalign);
  if(blockalign != rblockalign || byterate != rbyterate && argc < 3)
  { printf("\nFile header is corrupt, fixing...");
    unsigned long datasizeFull;
    fseek(fin, 4, 0);
    fread(&datasizeFull, 4, 1, fin);
    fseek(fin, 40, 0);
    unsigned long datasize;
    fread(&datasize, 4, 1, fin);
    buffer = (char*) malloc (datasize);
    if(!buffer)
    { printf("\nError allocating space, be sure you have enough memory.");
      fclose(fin);
      exit(2);
    }
    fread(buffer, 1, datasize, fin);
    fclose(fin);
    fout = fopen(argv[1], "wb");
    fputs("RIFF", fout);
    fwrite(&datasizeFull, 4, 1, fout);
    fputs("WAVEfmt ", fout);
    datasizeFull = 16;
    fwrite(&datasizeFull, 4, 1, fout);
    fwrite(&format, 2, 1, fout);
    fwrite(&channels, 2, 1, fout);
    fwrite(&samprate, 4, 1, fout);
    fwrite(&rbyterate, 4, 1, fout);
    fwrite(&rblockalign, 2, 1, fout);
    fwrite(&bitsamp, 2, 1, fout);
    fputs("data", fout);
    fwrite(&datasize, 4, 1, fout);
    fwrite(buffer, 1, datasize, fout);
    printf("\nCompleted!  File fixed!");
    fclose(fout);
    free(buffer);
  }
  else
  {fclose(fin);}
  return 0;
}
