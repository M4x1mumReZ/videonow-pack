Wavefix is designed to fix files created by VideoThen.  To use drag the file created by Videothen onto wavfix.
Minimum requirements: 256 megs of RAM.
Do not use this program with files created by programs other than VideoThen.