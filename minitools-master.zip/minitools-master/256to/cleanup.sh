find . -iname "*.tga" -delete
find . -iname "*.txt" -delete
find . -type d -delete
